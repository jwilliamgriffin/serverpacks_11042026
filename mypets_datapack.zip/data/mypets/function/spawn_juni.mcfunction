summon wolf ~ ~ ~ {variant:"mypets:juni",CustomName:"Juni",PersistenceRequired:1b,Tags:["mypets_new"]}
data modify entity @n[tag=mypets_new] Owner set from entity @s UUID
tag @n[tag=mypets_new] remove mypets_new
