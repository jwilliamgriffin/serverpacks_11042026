summon wolf ~ ~ ~ {variant:"mypets:grizzly",CustomName:"Grizzly",PersistenceRequired:1b,Tags:["mypets_new"]}
data modify entity @n[tag=mypets_new] Owner set from entity @s UUID
tag @n[tag=mypets_new] remove mypets_new
summon wolf ~ ~ ~ {variant:"mypets:juni",CustomName:"Juni",PersistenceRequired:1b,Tags:["mypets_new"]}
data modify entity @n[tag=mypets_new] Owner set from entity @s UUID
tag @n[tag=mypets_new] remove mypets_new
summon cat ~ ~ ~ {variant:"mypets:garcia",CustomName:"Garcia",PersistenceRequired:1b,Tags:["mypets_new"]}
data modify entity @n[tag=mypets_new] Owner set from entity @s UUID
tag @n[tag=mypets_new] remove mypets_new
summon cat ~ ~ ~ {variant:"mypets:otis",CustomName:"Otis",PersistenceRequired:1b,Tags:["mypets_new"]}
data modify entity @n[tag=mypets_new] Owner set from entity @s UUID
tag @n[tag=mypets_new] remove mypets_new
